from django.apps import AppConfig


class FoodblogConfig(AppConfig):
    name = 'foodblog'
